package br.edu.iftm.stalkerricardomutao;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

import br.edu.iftm.stalkerricardomutao.data.DAOPerson;
import br.edu.iftm.stalkerricardomutao.model.Person;

public class InsertActivity extends AppCompatActivity {

    public static final String RECORD_KEY = "br.edu.iftm.StalkerRicardoMutao.InsertActivity.NAME";//PARA BUNDLE

    private EditText ptxtFN;
    private EditText ptxtLN;
    private EditText ptxtAge;
    private EditText ptxtJob;
    private EditText ptxtBir;
    private EditText ptxtPhone;
    private EditText ptxtDesc;
    private ImageButton imgBtnPic;
    private static final int CAMERA_CODE = 0000;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert);

        ptxtFN = (EditText)findViewById(R.id.ptxtFN);
        ptxtLN = (EditText)findViewById(R.id.ptxtLN);
        ptxtAge = (EditText)findViewById(R.id.ptxtAge);
        ptxtJob = (EditText)findViewById(R.id.ptxtJob);
        ptxtBir = (EditText)findViewById(R.id.ptxtBir);
        ptxtPhone = (EditText)findViewById(R.id.ptxtPhone);
        ptxtDesc = (EditText)findViewById(R.id.ptxtDesc);
        imgBtnPic = (ImageButton)findViewById(R.id.imgBtnpic);


    }

    public void onClickSave(View view) {

        Person p = new Person(ptxtFN.getText().toString(),
                ptxtLN.getText().toString(),
                ptxtAge.getText().toString(),
                ptxtJob.getText().toString(),
                ptxtBir.getText().toString(),
                ptxtPhone.getText().toString(),
                ptxtDesc.getText().toString(),
                ((BitmapDrawable)imgBtnPic.getDrawable()).getBitmap());


        DAOPerson.getINSTANCE().addPerson(p);
        finish();

    }

    public void onClickTakePic(View view){
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) != null){
            startActivityForResult(intent, CAMERA_CODE);
        }
        Bitmap bitmap = ((BitmapDrawable)imgBtnPic.getDrawable()).getBitmap();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == CAMERA_CODE && resultCode == RESULT_OK && data != null){
            Bundle bundle = data.getExtras();
            if(bundle != null && bundle.containsKey("data")){
                Bitmap bitmap = (Bitmap) bundle.get("data");
                imgBtnPic.setImageBitmap(bitmap);
            }


        }
    }
}
