package br.edu.iftm.stalkerricardomutao;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import br.edu.iftm.stalkerricardomutao.data.DAOPerson;
import br.edu.iftm.stalkerricardomutao.model.Person;
import br.edu.iftm.stalkerricardomutao.view.PeopleListAdapter;

public class MainActivity extends AppCompatActivity implements PeopleListAdapter.PersonListener {

        private RecyclerView rvPeopleList;
        private PeopleListAdapter peopleListAdapter;
        public static final String PERSON_KEY = "br.edu.iftm.StalkerRicardoMutao.MainActivity.NAME";
        @Override
        protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rvPeopleList = findViewById(R.id.rvPeopleList);
        peopleListAdapter = new PeopleListAdapter(this);
        rvPeopleList.setLayoutManager(new LinearLayoutManager(this));
        rvPeopleList.setHasFixedSize(true);
        rvPeopleList.setAdapter(peopleListAdapter);
    }

        @Override
        public void onClickPersonListener(Person p) {
        Intent intent = new Intent(getBaseContext(), ShowPersonActivity.class);
        intent.putExtra(PERSON_KEY, p);
        startActivity(intent);
    }
}
